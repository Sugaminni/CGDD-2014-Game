using UnityEngine;

public class ShotgunWeapon : WeaponBase
{
    [Min(1)]
    public int pellets = 8;
    [Range(0f, 15f)]
    public float spread = 5f;

    public override void Use()
    {
        if (!CanFire()) return;
        SpawnFromCameraForward(pellets, spread);
    }
}
