using UnityEngine;

[RequireComponent(typeof(Collider))]
public class WeaponPickup : MonoBehaviour
{
    [Tooltip("Prefab that has a WeaponBase component on its root.")]
    public WeaponBase weaponPrefab;

    [Tooltip("Optional explicit parent for the weapon instance (e.g., Player/WeaponHolder). If null, uses inventory.weaponMount or inventory.transform.")]
    public Transform attachParentOverride;

    private void Reset()
    {
        // Ensure collider is a trigger
        var col = GetComponent<Collider>();
        if (col) col.isTrigger = true;
    }

    private void OnTriggerEnter(Collider other)
{
    Transform root = other.transform.root;

    var inventory = root.GetComponentInChildren<WeaponInventory>(true);
    var switcher  = root.GetComponentInChildren<WeaponSwitcher>(true);

    if (!weaponPrefab) { Debug.LogWarning("[WeaponPickup] No weaponPrefab", this); return; }
    if (!inventory)    { Debug.LogWarning($"[WeaponPickup] No WeaponInventory on '{root.name}' (hit '{other.name}')", this); return; }

    // Choose parent: override > inventory.weaponMount > inventory.transform
    Transform parent = inventory.weaponMount ? inventory.weaponMount : inventory.transform;
    if (attachParentOverride) parent = attachParentOverride;

    // Instantiate under the correct parent
    WeaponBase newWpn = Instantiate(weaponPrefab, parent);
    newWpn.transform.localPosition = Vector3.zero;
    newWpn.transform.localRotation = Quaternion.identity;

    // Ensure it sits under the mount and is tracked
    if (!inventory.owned.Contains(newWpn))
        inventory.owned.Add(newWpn);

    // Rebuild the list from children so index & list stay in sync
    inventory.RefreshOwned("Pickup");

    // Select the newly added weapon if switcher exists
    if (switcher != null)
        switcher.EquipIndex(inventory.owned.Count - 1);
    else
        Debug.Log("[WeaponPickup] Added to inventory but no WeaponSwitcher found; not auto-selected.", this);

    Debug.Log($"[WeaponPickup] Now have {inventory.owned.Count} weapon(s). Parent = '{parent.name}'");

    Destroy(gameObject);
}

}