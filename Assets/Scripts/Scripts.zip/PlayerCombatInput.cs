using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerCombatInput : MonoBehaviour
{
    public WeaponSwitcher switcher;
    private bool fireHeld;

    // Initialize references
    void Awake()
    {
        if (!switcher) switcher = GetComponentInChildren<WeaponSwitcher>();
    }

    void Update()
    {
        var w = switcher ? switcher.Current() : null;
        if (!w) return;

        // Hold-to-fire; fire rate is enforced in WeaponBase.CanFire()
        if (fireHeld) w.Use();
    }

    // Input System 
    void OnFire(InputValue v)   { fireHeld = v.isPressed; }
    void OnNextWeapon()         { switcher?.EquipNext(); }
    void OnPrevWeapon()         { switcher?.EquipPrev(); }
    void OnEquip1()             { switcher?.EquipIndex(0); }
    void OnEquip2()             { switcher?.EquipIndex(1); }
    void OnEquip3()             { switcher?.EquipIndex(2); }
}
