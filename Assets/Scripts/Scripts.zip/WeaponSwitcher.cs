using UnityEngine;

public class WeaponSwitcher : MonoBehaviour
{
    public WeaponInventory inventory;         
    public CrosshairUI crosshair;          
    private int index;

    // Initialize
    void Start()
    {
    if (inventory && inventory.owned.Count > 0)
        EquipIndex(0); // select first weapon
    }

    public void EquipIndex(int idx)
    {
        if (inventory == null || inventory.owned.Count == 0) return;

        var old = Current();
        if (old != null) old.OnFired = null;

        // Wrap
        if (idx < 0) idx = inventory.owned.Count - 1;
        if (idx >= inventory.owned.Count) idx = 0;
        index = idx;

        var w = Current();
        if (w != null)
        {
            w.OnFired += () => { if (crosshair) crosshair.Kick(); };
        }

        RefreshHUD(); 
    }

    public void EquipNext() => EquipIndex(index + 1);
    public void EquipPrev() => EquipIndex(index - 1);

    public WeaponBase Current()
    {
        if (inventory == null || inventory.owned.Count == 0) return null;
        return inventory.owned[Mathf.Clamp(index, 0, inventory.owned.Count - 1)];
    }

    void RefreshHUD()
    {
        var w = Current();
        SendMessage("OnWeaponChanged", w, SendMessageOptions.DontRequireReceiver);
    }
}
